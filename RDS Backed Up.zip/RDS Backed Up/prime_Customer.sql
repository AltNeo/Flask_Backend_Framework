-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: main.cdc46auas6j8.ap-southeast-2.rds.amazonaws.com    Database: prime
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `mail` varchar(40) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `address` varchar(100) NOT NULL,
  `cart_item` varchar(200) NOT NULL,
  `joindate` date NOT NULL,
  `enquiry` varchar(200) NOT NULL,
  `orderHistory` varchar(200) DEFAULT NULL,
  `pin` int DEFAULT NULL,
  `session_key` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customer`
--

LOCK TABLES `Customer` WRITE;
/*!40000 ALTER TABLE `Customer` DISABLE KEYS */;
INSERT INTO `Customer` VALUES (1,'John Doe','john.doe@example.com','1234567890','123 Main St, Anytown, USA','item1, item2, item3','2022-01-01','Enquiry about product X','Order history for customer John Doe',6969,NULL),(2,'Jane Smith','jane.smith@example.com','0987654321','456 Elm St, Othertown, USA','item4, item5','2022-01-02','Enquiry about product Y','Order history for customer Jane Smith',5678,NULL),(3,'Alice Johnson','alice.johnson@example.com','1112223333','789 Oak St, Anothertown, USA','item6, item7','2022-01-03','Enquiry about product Z','Order history for customer Alice Johnson',9012,NULL),(4,'Bob Brown','bob.brown@example.com','4445556666','101 Pine St, Yetanothertown, USA','item8, item9','2022-01-04','Enquiry about product W','Order history for customer Bob Brown',3456,NULL),(5,'Eve Williams','eve.williams@example.com','7778889999','202 Cedar St, Lasttown, USA','item10, item11','2022-01-05','Enquiry about product V','Order history for customer Eve Williams',7890,NULL),(6,'Charlie Davis','charlie.davis@example.com','1231231234','303 Walnut St, Finaltown, USA','item12, item13','2022-01-06','Enquiry about product U','Order history for customer Charlie Davis',2345,NULL),(7,'Grace Miller','grace.miller@example.com','5675675678','404 Maple St, Endtown, USA','item14, item15','2022-01-07','Enquiry about product T','Order history for customer Grace Miller',6789,NULL);
/*!40000 ALTER TABLE `Customer` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-30 22:35:24
