-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: main.cdc46auas6j8.ap-southeast-2.rds.amazonaws.com    Database: prime
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Enquiry`
--

DROP TABLE IF EXISTS `Enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Enquiry` (
  `enquiry_id` varchar(50) NOT NULL,
  `customer_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `response` varchar(200) NOT NULL,
  `response_date` date NOT NULL,
  `design_upload` varchar(200) NOT NULL,
  `enquiry_text` varchar(200) NOT NULL,
  `enquiry_quantity` int NOT NULL,
  `enquiry_status` varchar(20) NOT NULL,
  `enquiry_quote` int NOT NULL,
  `product_id` int DEFAULT NULL,
  PRIMARY KEY (`enquiry_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `Enquiry_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `Product` (`product_id`),
  CONSTRAINT `Enquiry_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `Customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Enquiry`
--

LOCK TABLES `Enquiry` WRITE;
/*!40000 ALTER TABLE `Enquiry` DISABLE KEYS */;
INSERT INTO `Enquiry` VALUES ('Enquiry 1',1,'2024-04-30 19:29:18','Response for Enquiry 1','2022-01-01','design_upload_for_enquiry_1','Enquiry text for Enquiry 1',10,'Pending',100,1),('Enquiry 2',2,'2024-04-30 19:29:18','Response for Enquiry 2','2022-01-02','design_upload_for_enquiry_2','Enquiry text for Enquiry 2',20,'Pending',200,2),('Enquiry 3',3,'2024-04-30 19:29:18','Response for Enquiry 3','2022-01-03','design_upload_for_enquiry_3','Enquiry text for Enquiry 3',30,'Pending',300,3),('Enquiry 4',4,'2024-04-30 19:29:18','Response for Enquiry 4','2022-01-04','design_upload_for_enquiry_4','Enquiry text for Enquiry 4',40,'Pending',400,4),('Enquiry 5',5,'2024-04-30 19:29:18','Response for Enquiry 5','2022-01-05','design_upload_for_enquiry_5','Enquiry text for Enquiry 5',50,'Pending',500,5);
/*!40000 ALTER TABLE `Enquiry` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-30 22:35:37
