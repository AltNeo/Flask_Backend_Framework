-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: main.cdc46auas6j8.ap-southeast-2.rds.amazonaws.com    Database: prime
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Product` (
  `name` varchar(20) NOT NULL,
  `price` int NOT NULL,
  `descr` varchar(200) NOT NULL,
  `product_id` int NOT NULL AUTO_INCREMENT,
  `stock` varchar(200) NOT NULL,
  `category_id` int NOT NULL,
  `estimated_price` varchar(200) NOT NULL,
  `GSM` int DEFAULT NULL,
  `material` varchar(200) NOT NULL,
  `margin` int NOT NULL,
  `displaystate` varchar(10) DEFAULT NULL,
  `color` varchar(255) NOT NULL,
  `images` text,
  PRIMARY KEY (`product_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `Product_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `Category` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product`
--

LOCK TABLES `Product` WRITE;
/*!40000 ALTER TABLE `Product` DISABLE KEYS */;
INSERT INTO `Product` VALUES ('Product 1',100,'Description for Product 1',1,'In stock',1,'Estimated price for Product 1',200,'Material for Product 1',10,'1','',NULL),('Product 2',200,'Description for Product 2',2,'In stock',2,'Estimated price for Product 2',300,'Material for Product 2',20,'1','',NULL),('Product 3',300,'Description for Product 3',3,'In stock',3,'Estimated price for Product 3',400,'Material for Product 3',30,'1','',NULL),('Product 4',400,'Description for Product 4',4,'In stock',4,'Estimated price for Product 4',500,'Material for Product 4',40,'1','',NULL),('Product 5',500,'Description for Product 5',5,'In stock',5,'Estimated price for Product 5',600,'Material for Product 5',50,'1','',NULL),('sweater',300,'comfy',7,'300',1,'2000',20,'cotton',20,'0','',NULL),('test5',577,'abcd',8,'30',2,'20000',20,'cotton',20,'1','',NULL),('test7',14354,'desc 1234',9,'69',2,'20000',20,'cotton',20,'1','',NULL),('test1',3000,'abcdefgh',10,'40',2,'2000',20,'teflon',20,'1','',NULL),('test1',3000,'abcdefgh',11,'40',2,'2000',20,'teflon',20,'1','',NULL),('Udit testing',6900,'Testing API',12,'500',2,'3000',3,'Plastic',69,'1','',NULL),('Udit testing',6900,'Testing API',13,'500',2,'3000',3,'Plastic',69,'1','',NULL);
/*!40000 ALTER TABLE `Product` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-30 22:35:16
